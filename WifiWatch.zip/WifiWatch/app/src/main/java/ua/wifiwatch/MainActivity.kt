package ua.wifiwatch

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.location.LocationManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.WindowInsets
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private companion object {
        const val REQ_BASIC = 1
        const val REQ_BG = 2
    }

    private lateinit var prefs: Prefs
    private lateinit var ssidEdit: EditText
    private lateinit var delayEdit: EditText
    private lateinit var statusText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        val pad = (16 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        root.addView(label("Имя Wi-Fi сети (SSID):"))
        ssidEdit = EditText(this).apply {
            setSingleLine()
            setText(prefs.ssid)
            hint = "например, HQ-WiFi"
        }
        root.addView(ssidEdit)
        root.addView(button("Подставить текущую сеть") { fillCurrentSsid() })

        root.addView(label("Задержка перед уведомлением, сек (0–600):"))
        delayEdit = EditText(this).apply {
            setSingleLine()
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(prefs.delaySec.toString())
        }
        root.addView(delayEdit)

        root.addView(button("Запустить мониторинг") { start() })
        root.addView(button("Остановить") { stop() })
        root.addView(button("Отключить оптимизацию батареи") { requestBatteryExemption() })

        statusText = TextView(this).apply { setPadding(0, pad, 0, 0); textSize = 15f }
        root.addView(statusText)

        val scroll = ScrollView(this).apply {
            clipToPadding = false
            addView(root)
            // targetSdk 35 = edge-to-edge, отступаем от системных панелей вручную
            setOnApplyWindowInsetsListener { v, insets ->
                val i = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.ime())
                v.setPadding(pad + i.left, pad + i.top, pad + i.right, pad + i.bottom)
                insets
            }
        }
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    // ---------- действия ----------

    private fun start() {
        val ssid = ssidEdit.text.toString().trim()
        if (ssid.isEmpty()) { toast("Укажите SSID"); return }
        prefs.ssid = ssid
        prefs.delaySec = delayEdit.text.toString().toIntOrNull() ?: 10

        val basic = buildList {
            add(Manifest.permission.ACCESS_FINE_LOCATION)
            add(Manifest.permission.ACCESS_COARSE_LOCATION) // на Android 12+ просить только вместе с FINE
            add(Manifest.permission.POST_NOTIFICATIONS)
        }.filter { !granted(it) }
        if (basic.isNotEmpty()) {
            requestPermissions(basic.toTypedArray(), REQ_BASIC)
            return
        }
        if (!granted(Manifest.permission.ACCESS_BACKGROUND_LOCATION)) {
            AlertDialog.Builder(this)
                .setTitle("Нужен доступ «Разрешить всегда»")
                .setMessage("Android скрывает имя Wi-Fi сети от фоновых приложений без этого разрешения. " +
                        "На следующем экране выберите «Разрешить всегда». Координаты приложение не читает.")
                .setPositiveButton("Далее") { _, _ ->
                    requestPermissions(arrayOf(Manifest.permission.ACCESS_BACKGROUND_LOCATION), REQ_BG)
                }
                .setNegativeButton("Отмена", null)
                .show()
            return
        }

        prefs.enabled = true
        startForegroundService(Intent(this, WifiWatchService::class.java))
        toast("Мониторинг «$ssid» запущен")
        statusText.postDelayed({ refreshStatus() }, 800)
    }

    private fun stop() {
        prefs.enabled = false
        stopService(Intent(this, WifiWatchService::class.java))
        statusText.postDelayed({ refreshStatus() }, 300)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        when {
            code == 0 -> if (granted(Manifest.permission.ACCESS_FINE_LOCATION)) fillCurrentSsid()
            code == REQ_BASIC && granted(Manifest.permission.ACCESS_FINE_LOCATION) -> start()
            code == REQ_BG && granted(Manifest.permission.ACCESS_BACKGROUND_LOCATION) -> start()
            else -> {
                toast("Без разрешения на точную геолокацию SSID недоступен")
                refreshStatus()
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun fillCurrentSsid() {
        if (!granted(Manifest.permission.ACCESS_FINE_LOCATION)) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION), 0)
            return
        }
        val ssid = getSystemService(WifiManager::class.java).connectionInfo?.ssid
            ?.removeSurrounding("\"")
        if (ssid.isNullOrEmpty() || ssid == WifiManager.UNKNOWN_SSID) {
            toast("Не удалось определить: Wi-Fi не подключён или выключена геолокация")
        } else {
            ssidEdit.setText(ssid)
        }
    }

    private fun requestBatteryExemption() {
        val pm = getSystemService(PowerManager::class.java)
        if (pm.isIgnoringBatteryOptimizations(packageName)) {
            toast("Оптимизация уже отключена")
            return
        }
        startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
            Uri.parse("package:$packageName")))
    }

    // ---------- статус ----------

    private fun refreshStatus() {
        val sb = StringBuilder()
        sb.append("Сервис: ").append(if (prefs.enabled) WifiWatchService.lastStatus else "Остановлен").append('\n')
        val warn = mutableListOf<String>()
        if (!granted(Manifest.permission.ACCESS_FINE_LOCATION)) warn += "нет доступа к точной геолокации"
        if (!granted(Manifest.permission.ACCESS_BACKGROUND_LOCATION)) warn += "нет «Разрешить всегда» для геолокации"
        if (!granted(Manifest.permission.POST_NOTIFICATIONS)) warn += "уведомления запрещены"
        if (!getSystemService(LocationManager::class.java).isLocationEnabled) warn += "геолокация выключена — SSID будет скрыт"
        if (!getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName))
            warn += "включена оптимизация батареи (Samsung может усыпить сервис)"
        if (warn.isNotEmpty()) sb.append("\n⚠ ").append(warn.joinToString("\n⚠ "))
        statusText.text = sb
    }

    // ---------- helpers ----------

    private fun granted(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun label(s: String) = TextView(this).apply { text = s; setPadding(0, 24, 0, 0) }
    private fun button(s: String, onClick: () -> Unit) = Button(this).apply {
        text = s
        setOnClickListener { onClick() }
    }
}
