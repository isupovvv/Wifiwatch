package ua.wifiwatch

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.WifiInfo
import android.net.wifi.WifiManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Foreground-сервис: следит за Wi-Fi сетями через NetworkCallback и, если пропала
 * сеть с заданным SSID (и за [Prefs.delaySec] не вернулась), показывает уведомление.
 */
class WifiWatchService : Service() {

    companion object {
        private const val CH_STATUS = "status"
        private const val CH_ALERT = "alert"
        private const val ID_STATUS = 1
        private const val ID_ALERT = 2

        @Volatile var lastStatus: String = "Остановлен"
            private set
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var cm: ConnectivityManager
    private lateinit var nm: NotificationManager

    /** SSID каждой текущей Wi-Fi сети. В onLost capabilities уже не приходят, поэтому запоминаем заранее. */
    private val ssidByNet = HashMap<Network, String>()
    private var target = ""
    private var delayMs = 10_000L
    private var pendingAlert: Runnable? = null
    private var registered = false

    // FLAG_INCLUDE_LOCATION_INFO — без него SSID в WifiInfo будет "<unknown ssid>" (API 31+)
    private val callback = object : ConnectivityManager.NetworkCallback(FLAG_INCLUDE_LOCATION_INFO) {

        override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
            val info = caps.transportInfo as? WifiInfo ?: return
            val ssid = info.ssid?.removeSurrounding("\"") ?: return
            if (ssid.isEmpty() || ssid == WifiManager.UNKNOWN_SSID) {
                setStatus("SSID скрыт системой: включите геолокацию и дайте доступ «Разрешить всегда»")
                return
            }
            val prev = ssidByNet.put(network, ssid)
            if (ssid == target && prev != ssid) {
                pendingAlert?.let { handler.removeCallbacks(it) }
                pendingAlert = null
                setStatus("Подключено к «$target»")
            } else if (prev == null && !ssidByNet.containsValue(target)) {
                setStatus("Ожидание «$target» (сейчас: $ssid)")
            }
        }

        override fun onLost(network: Network) {
            val ssid = ssidByNet.remove(network) ?: return
            if (ssid != target || ssidByNet.containsValue(target)) return
            setStatus("Соединение с «$target» потеряно")
            scheduleAlert()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        cm = getSystemService(ConnectivityManager::class.java)
        nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_STATUS, "Статус мониторинга", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_ALERT, "Потеря Wi-Fi", NotificationManager.IMPORTANCE_HIGH).apply {
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 400, 200, 400)
            }
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val p = Prefs(this)
        target = p.ssid
        delayMs = p.delaySec * 1000L

        // startForeground обязан быть вызван сразу после startForegroundService
        startForeground(ID_STATUS, statusNotification("Запуск…"),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)

        if (target.isEmpty()) {
            stopSelf()
            return START_NOT_STICKY
        }

        if (!registered) {
            val req = NetworkRequest.Builder()
                .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) // сети без интернета тоже считаем
                .build()
            cm.registerNetworkCallback(req, callback, handler)
            registered = true
            setStatus("Ожидание «$target»")
        } else {
            // Настройки изменились при работающем сервисе
            setStatus(if (ssidByNet.containsValue(target)) "Подключено к «$target»" else "Ожидание «$target»")
        }
        return START_STICKY
    }

    override fun onDestroy() {
        if (registered) runCatching { cm.unregisterNetworkCallback(callback) }
        registered = false
        handler.removeCallbacksAndMessages(null)
        lastStatus = "Остановлен"
        super.onDestroy()
    }

    private fun scheduleAlert() {
        pendingAlert?.let { handler.removeCallbacks(it) }
        val r = Runnable {
            pendingAlert = null
            if (!ssidByNet.containsValue(target)) showAlert()
        }
        pendingAlert = r
        handler.postDelayed(r, delayMs)
    }

    private fun showAlert() {
        val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        val n = Notification.Builder(this, CH_ALERT)
            .setSmallIcon(R.drawable.ic_wifi_off)
            .setContentTitle("Wi-Fi «$target» потерян")
            .setContentText("Телефон отключился от сети в $time")
            .setCategory(Notification.CATEGORY_STATUS)
            .setContentIntent(openAppIntent())
            .setAutoCancel(true)
            .setShowWhen(true)
            .build()
        nm.notify(ID_ALERT, n)
        setStatus("Отключено от «$target» с $time")
    }

    private fun setStatus(text: String) {
        lastStatus = text
        nm.notify(ID_STATUS, statusNotification(text))
    }

    private fun statusNotification(text: String): Notification =
        Notification.Builder(this, CH_STATUS)
            .setSmallIcon(R.drawable.ic_wifi_off)
            .setContentTitle("Мониторинг Wi-Fi")
            .setContentText(text)
            .setOngoing(true)
            .setContentIntent(openAppIntent())
            .build()

    private fun openAppIntent(): PendingIntent =
        PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
}
