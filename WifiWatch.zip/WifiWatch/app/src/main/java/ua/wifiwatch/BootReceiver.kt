package ua.wifiwatch

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Перезапускает мониторинг после перезагрузки телефона или обновления приложения. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_BOOT_COMPLETED, Intent.ACTION_MY_PACKAGE_REPLACED -> {
                val p = Prefs(context)
                if (p.enabled && p.ssid.isNotEmpty()) {
                    context.startForegroundService(Intent(context, WifiWatchService::class.java))
                }
            }
        }
    }
}
