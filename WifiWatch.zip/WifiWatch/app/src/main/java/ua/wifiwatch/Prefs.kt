package ua.wifiwatch

import android.content.Context

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    /** SSID отслеживаемой сети (без кавычек, с учётом регистра). */
    var ssid: String
        get() = sp.getString("ssid", "") ?: ""
        set(v) = sp.edit().putString("ssid", v.trim()).apply()

    /** Задержка перед уведомлением, сек. Гасит ложные срабатывания при кратковременном реконнекте. */
    var delaySec: Int
        get() = sp.getInt("delay", 10)
        set(v) = sp.edit().putInt("delay", v.coerceIn(0, 600)).apply()

    /** Мониторинг включён пользователем (используется для автозапуска после перезагрузки). */
    var enabled: Boolean
        get() = sp.getBoolean("enabled", false)
        set(v) = sp.edit().putBoolean("enabled", v).apply()
}
